import React, {Component} from 'react'

export default class QuizList extends Component {
  render() {
    return (
      <div>
        <h1>Quiz List</h1>
      </div>
    )
  }
}