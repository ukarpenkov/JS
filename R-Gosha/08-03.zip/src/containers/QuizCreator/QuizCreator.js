import React, {Component} from 'react'

export default class QuizCreator extends Component {
  render() {
    return (
      <div>
        <h1>Quiz Creator</h1>
      </div>
    )
  }
}