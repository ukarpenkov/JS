import React from 'react'
import './About.scss'

const About = props => (
  <div className="About">
    <h1>About page</h1>
  </div>
)


export default About